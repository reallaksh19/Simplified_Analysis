# Audit Fix Note

This corrected pack fixes issues found during zip audit:

1. `viewerToSketcherAdapter.js` now uses `.js` extensions for Node ESM behavior-test imports.
2. `v18b-sketcher-display-behavior-test.mjs` now checks the actual multiline `showNodeCoordinates` implementation instead of a brittle single-line string.
3. `PATCH_PACK_0_README.md` now gives the correct command when the zip extracts into a nested folder.

Status: corrected pack is suitable for application testing, but final certification still requires running it against the live repository with `npm run build`.
