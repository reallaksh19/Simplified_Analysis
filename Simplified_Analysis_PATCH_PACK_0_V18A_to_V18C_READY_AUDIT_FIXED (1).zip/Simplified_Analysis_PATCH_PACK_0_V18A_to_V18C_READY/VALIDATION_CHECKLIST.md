# Validation Checklist — Patch Pack 0

## Commands

```bash
npm run check:v18a
npm run check:v18a:behavior
npm run check:v18b
npm run check:v18b:behavior
npm run check:v18c
npm run check:v18c:behavior
npm run build
```

## Browser smoke

1. Open app.
2. Open 2D Sketcher.
3. Confirm Display panel exists.
4. Toggle node coordinates.
5. Toggle segment lengths.
6. Confirm bottom Element Listing panel exists.
7. Confirm tabs:
   - Pipes
   - Fittings
   - Components
   - Supports
   - Warnings
8. Import from 3D/viewer/canonical source and confirm diagnostics are visible if applicable.
