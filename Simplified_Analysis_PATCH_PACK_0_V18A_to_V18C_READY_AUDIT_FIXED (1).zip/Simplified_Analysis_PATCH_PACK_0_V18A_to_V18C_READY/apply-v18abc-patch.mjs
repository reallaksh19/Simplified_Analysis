import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const packRoot = path.dirname(fileURLToPath(import.meta.url));
const repoRoot = process.cwd();
const payloadRoot = path.join(packRoot, 'payload');

function log(message) { console.log(`[V18A-C] ${message}`); }
function fail(message) { console.error(`[V18A-C] ERROR: ${message}`); process.exit(1); }
function read(rel) { return fs.readFileSync(path.join(repoRoot, rel), 'utf8'); }
function write(rel, text) { const full = path.join(repoRoot, rel); fs.mkdirSync(path.dirname(full), { recursive: true }); fs.writeFileSync(full, text, 'utf8'); }
function copyPayload(rel) { const source = path.join(payloadRoot, rel); if (!fs.existsSync(source)) fail(`Payload file missing: ${rel}`); write(rel, fs.readFileSync(source, 'utf8')); log(`wrote ${rel}`); }
function patchFile(rel, patcher) { const full = path.join(repoRoot, rel); if (!fs.existsSync(full)) fail(`Target file missing: ${rel}`); const before = fs.readFileSync(full, 'utf8'); const after = patcher(before); if (after !== before) { fs.writeFileSync(full, after, 'utf8'); log(`patched ${rel}`); } else { log(`no changes needed in ${rel}`); } }
function replaceOnce(text, needle, replacement, label) { if (text.includes(replacement)) return text; if (!text.includes(needle)) fail(`Could not find patch point: ${label}`); return text.replace(needle, replacement); }
function insertAfter(text, needle, insertion, label) { if (text.includes(insertion.trim())) return text; if (!text.includes(needle)) fail(`Could not find insertion point: ${label}`); return text.replace(needle, `${needle}${insertion}`); }

for (const file of [
  'src/sketcher/adapters/viewerToSketcherAdapter.js',
  'src/sketcher/SketcherDisplaySettingsPanel.jsx',
  'src/sketcher/ElementListingPanel.jsx',
  'scripts/v18a-viewer-to-sketcher-adapter-check.mjs',
  'scripts/v18a-viewer-to-sketcher-adapter-behavior-test.mjs',
  'scripts/v18b-sketcher-display-check.mjs',
  'scripts/v18b-sketcher-display-behavior-test.mjs',
  'scripts/v18c-element-listing-panel-check.mjs',
  'scripts/v18c-element-listing-panel-behavior-test.mjs',
]) copyPayload(file);

patchFile('src/sketcher/SketcherStore.js', (input) => {
  let text = input;
  text = insertAfter(text, "import { serializePCFX, parsePCFXText, downloadTextFile, makePCFXFilename } from '../core/pcfx/pcfxFileUtils.js';\n", "import { convertViewerComponentsToSketcher } from './adapters/viewerToSketcherAdapter.js';\n", 'SketcherStore import viewerToSketcherAdapter');
  text = insertAfter(text, "  importWarnings: [],\n", "  lastImportDiagnostics: [],\n  lastImportLossContract: [],\n", 'SketcherStore import diagnostics state');

  const oldImportFromComponents = `  importFromComponents: (components) => {
      get().saveSnapshot();
      const { nodes, segments, warnings } = buildGraphFromComponents(components);
      set({ nodes, segments, importWarnings: warnings || [] });
  },

`;

  const newImportFromComponents = `  importFromComponents: (components) => {
      get().importFromViewerComponents(components);
  },

  importFromViewerComponents: (components, options = {}) => {
      get().saveSnapshot();
      const result = convertViewerComponentsToSketcher(components, {
          source: options.source || 'viewer-components',
          toleranceMm: options.toleranceMm ?? 1.0,
      });

      set({
          nodes: result.nodes || {},
          segments: result.segments || [],
          importWarnings: (result.diagnostics || []).map((item) => item.message || String(item)),
          lastImportDiagnostics: result.diagnostics || [],
          lastImportLossContract: result.lossContract || [],
          topologyDiagnostics: result.diagnostics || [],
          showTopologyDiagnostics: (result.diagnostics || []).length > 0,
          lastDraftingCommand: 'IMPORT_VIEWER_TO_SKETCHER',
      });

      get().triggerAutoCenter();
      return result;
  },

`;

  text = replaceOnce(text, oldImportFromComponents, newImportFromComponents, 'SketcherStore importFromComponents replacement');
  text = insertAfter(text, "  showLengthLabels: true,\n", "  showNodeCoordinates: true,\n  showGrid: true,\n  labelOpacity: 0.75,\n  gridOpacity: 0.32,\n  measureMode: false,\n", 'SketcherStore display state');
  text = insertAfter(text, "  toggleLengthLabels: () => set(s => ({ showLengthLabels: !s.showLengthLabels })),\n", "  toggleNodeCoordinates: () => set(s => ({ showNodeCoordinates: !s.showNodeCoordinates })),\n  toggleGrid: () => set(s => ({ showGrid: !s.showGrid })),\n  setLabelOpacity: (labelOpacity) => set({ labelOpacity }),\n  setGridOpacity: (gridOpacity) => set({ gridOpacity }),\n  setMeasureMode: (measureMode) => set({ measureMode }),\n", 'SketcherStore display actions');
  return text;
});

patchFile('src/sketcher/SketcherAnnotations.jsx', (input) => {
  let text = input;
  text = insertAfter(text, "    const showLengthLabels = useSketchStore(s => s.showLengthLabels);\n", "    const showNodeCoordinates = useSketchStore(s => s.showNodeCoordinates ?? true);\n    const labelOpacity = useSketchStore(s => s.labelOpacity ?? 0.75);\n", 'SketcherAnnotations display state');
  text = replaceOnce(text, "                const labelStr = `${id} (${Math.round(node.pos[0])}, ${Math.round(node.pos[1])}, ${Math.round(node.pos[2])})`;\n", "                const labelStr = showNodeCoordinates\n                    ? `${id} (${Math.round(node.pos[0])}, ${Math.round(node.pos[1])}, ${Math.round(node.pos[2])})`\n                    : id;\n", 'SketcherAnnotations coordinate label toggle');
  text = text.replace('bgAlpha={0.75}', 'bgAlpha={labelOpacity}');
  text = text.replace('bgAlpha={0.65}', 'bgAlpha={Math.max(0.05, labelOpacity * 0.9)}');
  return text;
});

patchFile('src/sketcher/SketcherTab.jsx', (input) => {
  let text = input;
  text = insertAfter(text, "import TopologyDiagnosticsPanel from './TopologyDiagnosticsPanel';\n", "import SketcherDisplaySettingsPanel from './SketcherDisplaySettingsPanel';\nimport ElementListingPanel from './ElementListingPanel';\n", 'SketcherTab imports display/element panels');
  text = text.replace("const { activeTool, setActiveTool, workingPlane, setWorkingPlane, importFromComponents, importFromCanonicalGeometry, exportToComponents, exportToCanonicalGeometry, clearSketch, exportSketch, importSketch } = useSketchStore();", "const { activeTool, setActiveTool, workingPlane, setWorkingPlane, importFromComponents, importFromViewerComponents, importFromCanonicalGeometry, exportToComponents, exportToCanonicalGeometry, clearSketch, exportSketch, importSketch } = useSketchStore();");
  text = text.replace("        importFromComponents(appComponents);\n", "        if (importFromViewerComponents) importFromViewerComponents(appComponents);\n        else importFromComponents(appComponents);\n");

  const globalSettingsNeedle = `            <div style={{ height: '1px', background: '#334155', width: '100%', margin: '4px 0' }} />

            <div style={{ display: 'flex', flexDirection: 'column', width: '100%', gap: '4px' }}>
                <span style={{ fontSize: '10px', color: '#94a3b8', textTransform: 'uppercase' }}>Global Settings</span>`;

  const globalSettingsReplacement = `            <div style={{ height: '1px', background: '#334155', width: '100%', margin: '4px 0' }} />

            <SketcherDisplaySettingsPanel />

            <div style={{ height: '1px', background: '#334155', width: '100%', margin: '4px 0' }} />

            <div style={{ display: 'flex', flexDirection: 'column', width: '100%', gap: '4px' }}>
                <span style={{ fontSize: '10px', color: '#94a3b8', textTransform: 'uppercase' }}>Global Settings</span>`;

  text = replaceOnce(text, globalSettingsNeedle, globalSettingsReplacement, 'SketcherTab insert display settings panel');

  if (!text.includes('<ElementListingPanel />')) {
    const candidates = ["</ErrorBoundary>\n        </div>", "</ErrorBoundary>\r\n        </div>", "<TopologyDiagnosticsPanel />"];
    let patched = false;
    for (const candidate of candidates) {
      if (text.includes(candidate)) {
        if (candidate.includes('TopologyDiagnosticsPanel')) text = text.replace(candidate, `${candidate}\n            <ElementListingPanel />`);
        else text = text.replace(candidate, `</ErrorBoundary>\n            <ElementListingPanel />\n        </div>`);
        patched = true;
        break;
      }
    }
    if (!patched) fail('Could not auto-insert ElementListingPanel into SketcherTab. Manually render <ElementListingPanel /> below the Sketcher canvas.');
  }
  return text;
});

patchFile('package.json', (input) => {
  const pkg = JSON.parse(input);
  pkg.scripts = pkg.scripts || {};
  const scripts = {
    'check:v18a': 'node scripts/v18a-viewer-to-sketcher-adapter-check.mjs',
    'check:v18a:behavior': 'node scripts/v18a-viewer-to-sketcher-adapter-behavior-test.mjs',
    'check:v18b': 'node scripts/v18b-sketcher-display-check.mjs',
    'check:v18b:behavior': 'node scripts/v18b-sketcher-display-behavior-test.mjs',
    'check:v18c': 'node scripts/v18c-element-listing-panel-check.mjs',
    'check:v18c:behavior': 'node scripts/v18c-element-listing-panel-behavior-test.mjs',
    'ci:v18c': 'npm run check:v18a && npm run check:v18a:behavior && npm run check:v18b && npm run check:v18b:behavior && npm run check:v18c && npm run check:v18c:behavior && npm run check:benchmarks && npm run build',
  };
  for (const [name, command] of Object.entries(scripts)) pkg.scripts[name] = pkg.scripts[name] || command;
  return `${JSON.stringify(pkg, null, 2)}\n`;
});

log('Patch Pack 0 V18A-C applied.');
log('Run: npm run check:v18a && npm run check:v18a:behavior && npm run check:v18b && npm run check:v18b:behavior && npm run check:v18c && npm run check:v18c:behavior && npm run build');
