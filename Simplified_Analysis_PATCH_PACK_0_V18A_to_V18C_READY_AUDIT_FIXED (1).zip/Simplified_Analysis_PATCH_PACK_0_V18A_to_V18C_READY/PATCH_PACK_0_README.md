# Simplified Analysis — Ready Patch Pack 0 (V18A to V18C)

This pack is designed for agents that failed with instruction-only packs.

It contains:
- full new source files
- full new validation scripts
- an executable patcher: `apply-v18abc-patch.mjs`

## Apply

Copy this folder into the root of `Simplified_Analysis` and run:

```bash
node apply-v18abc-patch.mjs
```

Then validate:

```bash
npm run check:v18a
npm run check:v18a:behavior
npm run check:v18b
npm run check:v18b:behavior
npm run check:v18c
npm run check:v18c:behavior
npm run build
```

## Included phases

- V18A — viewer/canonical import adapter into Sketcher
- V18B — display controls: hide node coordinates, hide segment lengths, label/grid opacity
- V18C — bottom element listing panel with Pipes / Fittings / Components / Supports / Warnings

## Patched files

- `src/sketcher/SketcherStore.js`
- `src/sketcher/SketcherTab.jsx`
- `src/sketcher/SketcherAnnotations.jsx`
- `package.json`

The patcher is intentionally strict. If it cannot find an expected insertion point, it stops and tells the agent what to manually patch.
