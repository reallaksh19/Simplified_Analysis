# Patch Pack 1 Audit Note

This pack was prepared against the current `main` repo shape where:

- `src/sketcher/SketcherStore.js` already contains core sketcher state/actions.
- `src/sketcher/SegmentEditorPanel.jsx` currently edits only flat `properties`.
- `package.json` has V16-era scripts and does not yet contain V18D/V18E/V18F scripts.

The pack adds full new files and replaces SegmentEditorPanel with a richer editor.

Final certification still requires applying in the actual repo and running:

```bash
npm run check:v18d
npm run check:v18d:behavior
npm run check:v18e
npm run check:v18e:behavior
npm run check:v18f
npm run check:v18f:behavior
npm run build
```


## Audit Fix 1

The earlier certification note could be read as over-certifying the integrated app based only on dependency presence.
This corrected pack makes dependency verification executable in `scripts/v18d-pipe-property-model-check.mjs`.

Fixes:
1. `SegmentEditorPanel.jsx` now imports `pipeSchedules.js` with an explicit `.js` extension.
2. V18D static check now verifies the actual repo exports:
   - `getPipeDimensions`
   - `getAvailableSchedules`
3. V18D static check now verifies `package.json` contains:
   - `"type": "module"`
   - `build`
   - `check:benchmarks`
   - V18D/V18E/V18F check scripts after patching

This makes the dependency statement test-backed instead of merely narrative.
