# Simplified Analysis — Patch Pack 1 (V18D to V18F)

This is a **ready-to-apply patch pack** for:

- **V18D** — Pipe property model in 2D Sketcher
- **V18E** — Component engineering object model
- **V18F** — Insert reducer / Flange-Valve-Flange commands

## Dependency

Apply and validate **Patch Pack 0 V18A–V18C** first.

## How to apply

Extract this zip into the root of the `Simplified_Analysis` repository. Then run from the repository root:

```bash
node Simplified_Analysis_PATCH_PACK_1_V18D_to_V18F_READY/apply-v18def-patch.mjs
```

Or copy the inner contents directly into the repo root and run:

```bash
node apply-v18def-patch.mjs
```

## Validation

```bash
npm run check:v18d
npm run check:v18d:behavior
npm run check:v18e
npm run check:v18e:behavior
npm run check:v18f
npm run check:v18f:behavior
npm run build
```

## Files added/replaced

```text
src/sketcher/pipeProperties/pipePropertyModel.js
src/sketcher/componentProperties/componentEngineeringModel.js
src/sketcher/commands/insertComponentCommands.js
src/sketcher/SegmentEditorPanel.jsx
scripts/v18d-pipe-property-model-check.mjs
scripts/v18d-pipe-property-model-behavior-test.mjs
scripts/v18e-component-engineering-model-check.mjs
scripts/v18e-component-engineering-model-behavior-test.mjs
scripts/v18f-insert-component-commands-check.mjs
scripts/v18f-insert-component-commands-behavior-test.mjs
```

## Existing files patched

```text
src/sketcher/SketcherStore.js
package.json
```

## Safety notes

The patcher is designed to be idempotent and stops with a clear error when a patch point cannot be found.


## Certification wording

This pack verifies dependency compatibility through `npm run check:v18d`.
That check confirms:
- `package.json` remains ESM-compatible with `"type": "module"`.
- `build` and `check:benchmarks` scripts are present.
- `pipeSchedules.js` exports `getPipeDimensions()` and `getAvailableSchedules()`.

This is still not the same as final integrated certification.
Final certification requires applying the pack to the real repo and running `npm run build`.
