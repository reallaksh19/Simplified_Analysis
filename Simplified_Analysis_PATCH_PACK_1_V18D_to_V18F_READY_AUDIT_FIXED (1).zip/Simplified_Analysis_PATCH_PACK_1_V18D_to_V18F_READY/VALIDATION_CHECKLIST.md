# Patch Pack 1 Validation Checklist

## Static checks

```bash
npm run check:v18d
npm run check:v18e
npm run check:v18f
```

## Behavior checks

```bash
npm run check:v18d:behavior
npm run check:v18e:behavior
npm run check:v18f:behavior
```

## Build

```bash
npm run build
```

## Manual UI smoke test

1. Open 2D Sketcher.
2. Draw one pipe segment.
3. Select the segment.
4. Confirm Segment Editor has:
   - Pipe section
   - Line / Component Class section
   - Temperature / Pressure section
   - Fluid / Insulation section
   - Calculation flags
5. Change DN, schedule, wall thickness, material.
6. Change rating class, face type, flange type, valve type.
7. Save/load sketch and confirm components/default pipe class are preserved.
8. Select a pipe segment and insert reducer/FVF after later UI quick buttons are wired.
