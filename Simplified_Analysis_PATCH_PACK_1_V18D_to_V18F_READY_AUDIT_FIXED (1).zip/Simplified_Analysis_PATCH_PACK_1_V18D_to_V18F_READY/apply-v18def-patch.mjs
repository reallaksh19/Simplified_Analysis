import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const packRoot = path.dirname(fileURLToPath(import.meta.url));
const repoRoot = process.cwd();
const payloadRoot = path.join(packRoot, 'payload');

function log(message) {
  console.log(`[V18D-F] ${message}`);
}

function fail(message) {
  console.error(`[V18D-F] ERROR: ${message}`);
  process.exit(1);
}

function write(rel, text) {
  const full = path.join(repoRoot, rel);
  fs.mkdirSync(path.dirname(full), { recursive: true });
  fs.writeFileSync(full, text, 'utf8');
}

function copyPayload(rel) {
  const source = path.join(payloadRoot, rel);
  if (!fs.existsSync(source)) fail(`Payload file missing: ${rel}`);
  write(rel, fs.readFileSync(source, 'utf8'));
  log(`wrote ${rel}`);
}

function patchFile(rel, patcher) {
  const full = path.join(repoRoot, rel);
  if (!fs.existsSync(full)) fail(`Target file missing: ${rel}`);
  const before = fs.readFileSync(full, 'utf8');
  const after = patcher(before);
  if (after !== before) {
    fs.writeFileSync(full, after, 'utf8');
    log(`patched ${rel}`);
  } else {
    log(`no changes needed in ${rel}`);
  }
}

function insertAfter(text, needle, insertion, label) {
  if (text.includes(insertion.trim())) return text;
  if (!text.includes(needle)) fail(`Could not find insertion point: ${label}`);
  return text.replace(needle, `${needle}${insertion}`);
}

function replaceOnce(text, needle, replacement, label) {
  if (text.includes(replacement)) return text;
  if (!text.includes(needle)) fail(`Could not find patch point: ${label}`);
  return text.replace(needle, replacement);
}

for (const file of [
  'src/sketcher/pipeProperties/pipePropertyModel.js',
  'src/sketcher/componentProperties/componentEngineeringModel.js',
  'src/sketcher/commands/insertComponentCommands.js',
  'src/sketcher/SegmentEditorPanel.jsx',
  'scripts/v18d-pipe-property-model-check.mjs',
  'scripts/v18d-pipe-property-model-behavior-test.mjs',
  'scripts/v18e-component-engineering-model-check.mjs',
  'scripts/v18e-component-engineering-model-behavior-test.mjs',
  'scripts/v18f-insert-component-commands-check.mjs',
  'scripts/v18f-insert-component-commands-behavior-test.mjs',
]) {
  copyPayload(file);
}

patchFile('src/sketcher/SketcherStore.js', (input) => {
  let text = input;

  text = insertAfter(
    text,
    "import { serializePCFX, parsePCFXText, downloadTextFile, makePCFXFilename } from '../core/pcfx/pcfxFileUtils.js';\n",
    "import { DEFAULT_PIPE_CLASS, applyPipeClassToSegment, validateSegmentPipeProperties } from './pipeProperties/pipePropertyModel.js';\nimport { validateComponentEngineeringData } from './componentProperties/componentEngineeringModel.js';\nimport { insertFlangeValveFlangeOnSegment, insertFlangeValveFlangeContinue as insertFlangeValveFlangeContinueCommand, insertReducerOnSegment } from './commands/insertComponentCommands.js';\n",
    'SketcherStore V18D-F imports',
  );

  text = insertAfter(
    text,
    "  segments: [],\n",
    "  components: {},\n",
    'SketcherStore components state',
  );

  text = insertAfter(
    text,
    "  designTemperature: 450, // Global default temperature (F)\n  setDesignTemperature: (temp) => set({ designTemperature: temp }),\n",
    "\n  defaultPipeClass: DEFAULT_PIPE_CLASS,\n  setDefaultPipeClass: (defaultPipeClass) => set({ defaultPipeClass }),\n",
    'SketcherStore default pipe class',
  );

  text = text.replace(
    "          nodes: JSON.parse(JSON.stringify(state.nodes)),\n          segments: JSON.parse(JSON.stringify(state.segments))",
    "          nodes: JSON.parse(JSON.stringify(state.nodes)),\n          segments: JSON.parse(JSON.stringify(state.segments)),\n          components: JSON.parse(JSON.stringify(state.components || {}))"
  );

  text = text.replace(
    "          nodes: previousState.nodes,\n          segments: previousState.segments,",
    "          nodes: previousState.nodes,\n          segments: previousState.segments,\n          components: previousState.components || {},"
  );

  text = text.replace(
    "          nodes: nextState.nodes,\n          segments: nextState.segments,",
    "          nodes: nextState.nodes,\n          segments: nextState.segments,\n          components: nextState.components || {},"
  );

  text = insertAfter(
    text,
    `  deleteSegment: (id) => {
      get().saveSnapshot();
      set((s) => ({
          segments: s.segments.filter(seg => seg.id !== id),
          selectedSegmentId: null,
      }));
  },

`,
    `  applyPipeClassToSegments: (segmentIds = [], pipeClass = get().defaultPipeClass) => {
      get().saveSnapshot();
      set((s) => ({
          segments: s.segments.map((seg) =>
              segmentIds.length === 0 || segmentIds.includes(seg.id)
                  ? applyPipeClassToSegment(seg, pipeClass)
                  : seg
          )
      }));
  },

  validatePipeProperties: () => {
      const diagnostics = [];
      for (const segment of get().segments || []) {
          if (String(segment.type || segment.properties?.type || 'PIPE').toUpperCase() !== 'PIPE') continue;
          diagnostics.push(...validateSegmentPipeProperties(segment).diagnostics);
      }
      set({ topologyDiagnostics: diagnostics, showTopologyDiagnostics: diagnostics.length > 0, lastDraftingCommand: 'VALIDATE_PIPE_PROPERTIES' });
      return diagnostics;
  },

  upsertComponent: (component) => {
      const validation = validateComponentEngineeringData(component);
      set((s) => ({
          components: { ...(s.components || {}), [component.id]: component },
          topologyDiagnostics: validation.diagnostics,
          showTopologyDiagnostics: validation.diagnostics.length > 0,
      }));
      return validation;
  },

  updateComponent: (componentId, updates) => set((s) => ({
      components: {
          ...(s.components || {}),
          [componentId]: { ...((s.components || {})[componentId] || {}), ...updates },
      },
  })),

  deleteComponent: (componentId) => set((s) => {
      const nextComponents = { ...(s.components || {}) };
      delete nextComponents[componentId];
      return {
          components: nextComponents,
          segments: s.segments.map((seg) => seg.componentId === componentId ? { ...seg, componentId: null, componentData: null } : seg),
      };
  }),

  validateComponents: () => {
      const diagnostics = [];
      for (const component of Object.values(get().components || {})) {
          diagnostics.push(...validateComponentEngineeringData(component).diagnostics);
      }
      set({ topologyDiagnostics: diagnostics, showTopologyDiagnostics: diagnostics.length > 0, lastDraftingCommand: 'VALIDATE_COMPONENTS' });
      return diagnostics;
  },

  applyInsertComponentCommandResult: (result) => {
      if (!result) return result;
      if (!result.ok) {
          set({
              topologyDiagnostics: result.diagnostics || [],
              showTopologyDiagnostics: true,
              lastDraftingCommand: result.command || 'INSERT_COMPONENT_FAILED',
          });
          return result;
      }
      get().saveSnapshot();
      set({
          nodes: result.nodes || get().nodes,
          segments: result.segments || get().segments,
          components: result.components || get().components || {},
          selectedSegmentId: result.selectedSegmentId ?? null,
          selectedNodeId: result.selectedNodeId ?? null,
          topologyDiagnostics: result.diagnostics || [],
          showTopologyDiagnostics: (result.diagnostics || []).length > 0,
          lastDraftingCommand: result.command || null,
      });
      return result;
  },

  insertFlangeValveFlangeOnSelectedSegment: (componentInput = {}, insertionDistance_mm = null) => {
      const state = get();
      const result = insertFlangeValveFlangeOnSegment({
          nodes: state.nodes,
          segments: state.segments,
          components: state.components || {},
          segmentId: state.selectedSegmentId,
          componentInput,
          insertionDistance_mm,
      });
      return get().applyInsertComponentCommandResult(result);
  },

  insertFlangeValveFlangeContinue: (componentInput = {}, direction = [1, 0, 0]) => {
      const state = get();
      const startNodeId = state.selectedNodeId || state.draftingState?.startNodeId;
      const result = insertFlangeValveFlangeContinueCommand({
          nodes: state.nodes,
          segments: state.segments,
          components: state.components || {},
          startNodeId,
          direction,
          componentInput,
      });
      return get().applyInsertComponentCommandResult(result);
  },

  insertReducerOnSelectedSegment: (componentInput = {}, insertionDistance_mm = null) => {
      const state = get();
      const result = insertReducerOnSegment({
          nodes: state.nodes,
          segments: state.segments,
          components: state.components || {},
          segmentId: state.selectedSegmentId,
          componentInput,
          insertionDistance_mm,
      });
      return get().applyInsertComponentCommandResult(result);
  },

`,
    'SketcherStore V18D-F actions',
  );

  text = replaceOnce(
    text,
    "      set(s => ({ segments: [...s.segments, { id, startNode: startNodeId, endNode: endNodeId, ...properties }] }));\n      return id;",
    "      const rawSegment = { id, startNode: startNodeId, endNode: endNodeId, ...properties };\n      const segment = String(rawSegment.type || rawSegment.properties?.type || 'PIPE').toUpperCase() === 'PIPE'\n          ? applyPipeClassToSegment(rawSegment, get().defaultPipeClass)\n          : rawSegment;\n      set(s => ({ segments: [...s.segments, segment] }));\n      return id;",
    'SketcherStore createSegment pipe class application',
  );

  text = text.replace(
    "      set({ nodes: {}, segments: [] });",
    "      set({ nodes: {}, segments: [], components: {} });"
  );

  text = text.replace(
    "      const { nodes, segments, workingPlane, workingElevation } = get();\n      const data = { version: 1, workingPlane, workingElevation, nodes, segments };",
    "      const { nodes, segments, components, workingPlane, workingElevation, defaultPipeClass } = get();\n      const data = { version: 2, workingPlane, workingElevation, nodes, segments, components, defaultPipeClass };"
  );

  text = text.replace(
    "              nodes: data.nodes,\n              segments: data.segments,\n              workingPlane: data.workingPlane || 'XY',\n              workingElevation: data.workingElevation ?? 0,\n              importWarnings: [],",
    "              nodes: data.nodes,\n              segments: data.segments,\n              components: data.components || {},\n              defaultPipeClass: data.defaultPipeClass || get().defaultPipeClass,\n              workingPlane: data.workingPlane || 'XY',\n              workingElevation: data.workingElevation ?? 0,\n              importWarnings: [],"
  );

  return text;
});

patchFile('package.json', (input) => {
  const pkg = JSON.parse(input);
  pkg.scripts = pkg.scripts || {};

  const scripts = {
    'check:v18d': 'node scripts/v18d-pipe-property-model-check.mjs',
    'check:v18d:behavior': 'node scripts/v18d-pipe-property-model-behavior-test.mjs',
    'check:v18e': 'node scripts/v18e-component-engineering-model-check.mjs',
    'check:v18e:behavior': 'node scripts/v18e-component-engineering-model-behavior-test.mjs',
    'check:v18f': 'node scripts/v18f-insert-component-commands-check.mjs',
    'check:v18f:behavior': 'node scripts/v18f-insert-component-commands-behavior-test.mjs',
    'ci:v18f': 'npm run ci:v18c && npm run check:v18d && npm run check:v18d:behavior && npm run check:v18e && npm run check:v18e:behavior && npm run check:v18f && npm run check:v18f:behavior && npm run check:benchmarks && npm run build',
  };

  for (const [name, command] of Object.entries(scripts)) {
    pkg.scripts[name] = pkg.scripts[name] || command;
  }

  return `${JSON.stringify(pkg, null, 2)}\n`;
});

log('Patch Pack 1 V18D-F applied.');
log('Next commands: npm run check:v18d && npm run check:v18d:behavior && npm run check:v18e && npm run check:v18e:behavior && npm run check:v18f && npm run check:v18f:behavior && npm run build');
