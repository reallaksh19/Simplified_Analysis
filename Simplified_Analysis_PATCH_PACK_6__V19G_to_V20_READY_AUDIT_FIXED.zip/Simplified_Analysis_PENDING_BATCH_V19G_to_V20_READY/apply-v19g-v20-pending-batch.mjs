import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const packRoot = path.dirname(fileURLToPath(import.meta.url));
const repoRoot = process.cwd();
const payloadRoot = path.join(packRoot, 'payload');

function log(message) { console.log(`[V19G-V20] ${message}`); }
function fail(message) { console.error(`[V19G-V20] ERROR: ${message}`); process.exit(1); }

function write(rel, text) {
  const full = path.join(repoRoot, rel);
  fs.mkdirSync(path.dirname(full), { recursive: true });
  fs.writeFileSync(full, text, 'utf8');
}

function copyPayload(rel) {
  const source = path.join(payloadRoot, rel);
  if (!fs.existsSync(source)) fail(`Payload missing: ${rel}`);
  write(rel, fs.readFileSync(source, 'utf8'));
  log(`wrote ${rel}`);
}

function patchFile(rel, patcher) {
  const full = path.join(repoRoot, rel);
  if (!fs.existsSync(full)) fail(`Target missing: ${rel}`);
  const before = fs.readFileSync(full, 'utf8');
  const after = patcher(before);
  if (after !== before) {
    fs.writeFileSync(full, after, 'utf8');
    log(`patched ${rel}`);
  } else {
    log(`no changes needed in ${rel}`);
  }
}

function assertPatchedFileContains(rel, tokens) {
  const full = path.join(repoRoot, rel);
  if (!fs.existsSync(full)) fail(`Post-patch file missing: ${rel}`);
  const source = fs.readFileSync(full, 'utf8');
  for (const token of tokens) if (!source.includes(token)) fail(`Post-patch validation failed: ${rel} missing ${token}`);
}

for (const file of [
  'src/data/masterDbBulkValidation.js',
  'src/masterDb/MasterDbBulkToolsPanel.jsx',
  'e2e/helpers/v19gMasterDbWorkflowHelpers.js',
  'e2e/v19g-master-db-browser.spec.js',
  'scripts/v19g-masterdb-browser-check.mjs',
  'scripts/v19g-masterdb-browser-behavior-test.mjs',
  'scripts/v19h-masterdb-bulk-validation-check.mjs',
  'scripts/v19h-masterdb-bulk-validation-behavior-test.mjs',
  'scripts/v20-final-combined-certification-check.mjs',
  'scripts/v20-final-combined-certification-behavior-test.mjs',
  'scripts/v20-final-combined-certification.mjs',
]) {
  copyPayload(file);
}

patchFile('src/masterDb/MasterDbEditorTab.jsx', (input) => {
  let text = input;

  if (!text.includes("import MasterDbBulkToolsPanel from './MasterDbBulkToolsPanel.jsx';")) {
    text = text.replace(
      "import MasterDbValidationPanel from './MasterDbValidationPanel.jsx';",
      "import MasterDbValidationPanel from './MasterDbValidationPanel.jsx';\nimport MasterDbBulkToolsPanel from './MasterDbBulkToolsPanel.jsx';",
    );
  }

  if (!text.includes('<MasterDbBulkToolsPanel />')) {
    text = text.replace('<MasterDbValidationPanel />', '<MasterDbValidationPanel />\n      <MasterDbBulkToolsPanel />');
  }

  return text;
});

patchFile('package.json', (input) => {
  const pkg = JSON.parse(input);
  pkg.scripts = pkg.scripts || {};

  const scripts = {
    'check:v19g': 'node scripts/v19g-masterdb-browser-check.mjs',
    'check:v19g:behavior': 'node scripts/v19g-masterdb-browser-behavior-test.mjs',
    'check:e2e:v19g': 'playwright test e2e/v19g-master-db-browser.spec.js',
    'check:v19h': 'node scripts/v19h-masterdb-bulk-validation-check.mjs',
    'check:v19h:behavior': 'node scripts/v19h-masterdb-bulk-validation-behavior-test.mjs',
    'check:v20': 'node scripts/v20-final-combined-certification-check.mjs',
    'check:v20:behavior': 'node scripts/v20-final-combined-certification-behavior-test.mjs',
    'certify:v20': 'node scripts/v20-final-combined-certification.mjs',
    'ci:v20': 'npm run check:v20 && npm run check:v20:behavior && npm run certify:v20',
  };

  for (const [name, command] of Object.entries(scripts)) {
    pkg.scripts[name] = pkg.scripts[name] || command;
  }

  return `${JSON.stringify(pkg, null, 2)}\n`;
});

assertPatchedFileContains('src/masterDb/MasterDbEditorTab.jsx', ['MasterDbBulkToolsPanel', '<MasterDbBulkToolsPanel />']);
assertPatchedFileContains('package.json', ['check:v19g', 'check:v19h', 'certify:v20']);

log('Pending batch V19G-V20 applied.');
