import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const packRoot = path.dirname(fileURLToPath(import.meta.url));
const repoRoot = process.cwd();
const payloadRoot = path.join(packRoot, 'payload');
function log(message) { console.log(`[V19] ${message}`); }
function fail(message) { console.error(`[V19] ERROR: ${message}`); process.exit(1); }
function write(rel, text) { const full = path.join(repoRoot, rel); fs.mkdirSync(path.dirname(full), { recursive: true }); fs.writeFileSync(full, text, 'utf8'); }
function copyPayload(rel) { const src = path.join(payloadRoot, rel); if (!fs.existsSync(src)) fail(`Payload missing: ${rel}`); write(rel, fs.readFileSync(src, 'utf8')); log(`wrote ${rel}`); }
function patchFile(rel, patcher) { const full = path.join(repoRoot, rel); if (!fs.existsSync(full)) fail(`Target missing: ${rel}`); const before = fs.readFileSync(full, 'utf8'); const after = patcher(before); if (after !== before) { fs.writeFileSync(full, after, 'utf8'); log(`patched ${rel}`); } else log(`no changes needed in ${rel}`); }
function insertAfter(text, needle, insertion, label) { if (text.includes(insertion.trim())) return text; if (!text.includes(needle)) fail(`Patch point missing: ${label}`); return text.replace(needle, `${needle}${insertion}`); }
function insertBefore(text, needle, insertion, label) { if (text.includes(insertion.trim())) return text; if (!text.includes(needle)) fail(`Patch point missing: ${label}`); return text.replace(needle, `${insertion}${needle}`); }

function assertPatchedFileContains(rel, tokens) {
  const full = path.join(repoRoot, rel);
  if (!fs.existsSync(full)) fail(`Post-patch file missing: ${rel}`);
  const source = fs.readFileSync(full, 'utf8');
  for (const token of tokens) {
    if (!source.includes(token)) fail(`Post-patch validation failed: ${rel} missing ${token}`);
  }
}

for (const file of [
  'src/data/legacy/wtValveweights.json','src/data/masterDbOverrides.js','src/data/componentWeightMasterDb.js','src/data/flangeDimensionalMasterDb.js','src/data/b169FittingDimensionalMasterDb.js',
  'src/core/engineering-data/resolveComponentData.js','src/core/engineering-data/resolveB169FittingData.js','src/core/engineering-data/validateMasterDbGovernance.js',
  'src/sketcher/componentProperties/componentMasterResolver.js','src/sketcher/componentProperties/b169FittingMasterResolver.js',
  'src/masterDb/MasterDbEditorTab.jsx','src/masterDb/MasterDbValidationPanel.jsx','src/3d-analysis/reporting/build3DSimplifiedCalculationReport.js',
  'scripts/v19-component-weight-master-check.mjs','scripts/v19-component-weight-master-behavior-test.mjs','scripts/v19b-flange-dimensional-master-check.mjs','scripts/v19b-flange-dimensional-master-behavior-test.mjs','scripts/v19c-master-db-editor-check.mjs','scripts/v19c-master-db-editor-behavior-test.mjs','scripts/v19d-master-db-governance-check.mjs','scripts/v19d-master-db-governance-behavior-test.mjs','scripts/v19e-b169-fitting-master-check.mjs','scripts/v19e-b169-fitting-master-behavior-test.mjs',
]) copyPayload(file);

patchFile('src/App.jsx', (input) => {
  let text = input;
  text = insertAfter(text, "import PipeRackTab from './piperack/components/PipeRackTab';\n", "import MasterDbEditorTab from './masterDb/MasterDbEditorTab.jsx';\n", 'App import MasterDbEditorTab');
  text = insertBefore(text, "      {activeTab === 'reports' && <ReportsTab />}", "      {activeTab === 'master-db' && <MasterDbEditorTab />}\n", 'App render master-db');
  return text;
});

patchFile('src/components/TopNav.jsx', (input) => {
  let text = input;
  if (!text.includes('Database')) {
    text = text.replace(/import \{([^}]+)\} from 'lucide-react';/, (match, icons) => {
      return `import {${icons}, Database } from 'lucide-react';`;
    });
  }
  text = text.replace('name="3D Guided Cantilever"', 'name="3D Simplified Calculation"');
  if (!text.includes('id="master-db"')) {
    const anchors = [
      '        <TabItem id="3d-analysis" name="3D Simplified Calculation" icon={Layers} />\n',
      '        <TabItem id="3d-analysis" name="3D Guided Cantilever" icon={Layers} />\n',
      '        <TabItem id="simpAnalysis" name="2D/3D/Pipe Rack Solver" icon={Activity} />\n',
    ];
    let inserted = false;
    for (const anchor of anchors) {
      if (text.includes(anchor)) {
        text = text.replace(anchor, `${anchor}        <TabItem id="master-db" name="Master DB" icon={Database} />\n`);
        inserted = true;
        break;
      }
    }
    if (!inserted) fail('Patch point missing: TopNav Master DB tab');
  }
  return text;
});

patchFile('src/sketcher/ElementListingPanel.jsx', (input) => {
  let text = input;
  text = insertAfter(text, "import { useSketchStore } from './SketcherStore';\n", "import { resolveFlangeValveFlangeInsertData } from './componentProperties/componentMasterResolver.js';\nimport { resolveReducerInsertData } from './componentProperties/b169FittingMasterResolver.js';\n", 'ElementListingPanel master resolver imports');
  const helper = `
function QuickInsertButtons() {
  const selectedSegmentId = useSketchStore((s) => s.selectedSegmentId);
  const segments = useSketchStore((s) => s.segments || []);
  const insertReducerOnSelectedSegment = useSketchStore((s) => s.insertReducerOnSelectedSegment);
  const insertFlangeValveFlangeOnSelectedSegment = useSketchStore((s) => s.insertFlangeValveFlangeOnSelectedSegment);
  const selectedSegment = segments.find((segment) => segment.id === selectedSegmentId);
  const selectedDn = selectedSegment?.pipe?.dn ?? selectedSegment?.properties?.bore ?? 200;
  const ratingClass = selectedSegment?.lineClass?.ratingClass ?? selectedSegment?.properties?.ratingClass ?? 300;
  const faceType = selectedSegment?.lineClass?.faceType ?? selectedSegment?.properties?.faceType ?? 'RF';
  const flangeType = selectedSegment?.lineClass?.flangeType ?? selectedSegment?.properties?.flangeType ?? 'WN';
  const valveType = selectedSegment?.lineClass?.valveType ?? selectedSegment?.properties?.valveType ?? 'Flanged Swing check Valve';
  const schedule = selectedSegment?.pipe?.schedule ?? selectedSegment?.properties?.schedule ?? 'STD';
  return (
    <div style={{ display: 'flex', gap: 6 }}>
      <button type="button" data-testid="element-panel-insert-reducer" disabled={!selectedSegmentId} style={{ ...actionButtonStyle, opacity: selectedSegmentId ? 1 : 0.45 }} onClick={() => { const targetDn = selectedDn > 50 ? selectedDn - 50 : selectedDn; insertReducerOnSelectedSegment(resolveReducerInsertData({ fromDn: selectedDn, toDn: targetDn, reducerType: 'CONCENTRIC', scheduleFrom: schedule, scheduleTo: schedule })); }}>Insert Reducer</button>
      <button type="button" data-testid="element-panel-insert-fvf" disabled={!selectedSegmentId} style={{ ...actionButtonStyle, opacity: selectedSegmentId ? 1 : 0.45 }} onClick={() => { insertFlangeValveFlangeOnSelectedSegment(resolveFlangeValveFlangeInsertData({ dn: selectedDn, ratingClass, valveType, flangeType, faceType })); }}>Insert F-V-F</button>
    </div>
  );
}

`;
  if (!text.includes('function QuickInsertButtons()')) text = text.replace('export default function ElementListingPanel()', `${helper}export default function ElementListingPanel()`);
  if (!text.includes('<QuickInsertButtons />')) text = text.replace("<strong style={{ color: '#e0f2fe' }}>Element Listing</strong>", "<strong style={{ color: '#e0f2fe' }}>Element Listing</strong>\n          <QuickInsertButtons />");
  return text;
});

patchFile('package.json', (input) => {
  const pkg = JSON.parse(input); pkg.scripts = pkg.scripts || {};
  const scripts = {
    'check:v19': 'node scripts/v19-component-weight-master-check.mjs',
    'check:v19:behavior': 'node scripts/v19-component-weight-master-behavior-test.mjs',
    'check:v19b': 'node scripts/v19b-flange-dimensional-master-check.mjs',
    'check:v19b:behavior': 'node scripts/v19b-flange-dimensional-master-behavior-test.mjs',
    'check:v19c': 'node scripts/v19c-master-db-editor-check.mjs',
    'check:v19c:behavior': 'node scripts/v19c-master-db-editor-behavior-test.mjs',
    'check:v19d': 'node scripts/v19d-master-db-governance-check.mjs',
    'check:v19d:behavior': 'node scripts/v19d-master-db-governance-behavior-test.mjs',
    'check:v19e': 'node scripts/v19e-b169-fitting-master-check.mjs',
    'check:v19e:behavior': 'node scripts/v19e-b169-fitting-master-behavior-test.mjs',
    'ci:v19e': 'npm run ci:v18l && npm run check:v19 && npm run check:v19:behavior && npm run check:v19b && npm run check:v19b:behavior && npm run check:v19c && npm run check:v19c:behavior && npm run check:v19d && npm run check:v19d:behavior && npm run check:v19e && npm run check:v19e:behavior && npm run check:benchmarks && npm run build'
  };
  for (const [name, command] of Object.entries(scripts)) pkg.scripts[name] = pkg.scripts[name] || command;
  return `${JSON.stringify(pkg, null, 2)}\n`;
});

assertPatchedFileContains('src/App.jsx', ['MasterDbEditorTab', "activeTab === 'master-db'"]);
assertPatchedFileContains('src/components/TopNav.jsx', ['Master DB', 'Database']);
assertPatchedFileContains('src/sketcher/ElementListingPanel.jsx', ['element-panel-insert-reducer', 'element-panel-insert-fvf', 'resolveReducerInsertData', 'resolveFlangeValveFlangeInsertData']);
assertPatchedFileContains('src/3d-analysis/reporting/build3DSimplifiedCalculationReport.js', ['Master DB Governance', 'masterDbGovernance']);

const componentMasterSource = fs.readFileSync(path.join(repoRoot, 'src/data/componentWeightMasterDb.js'), 'utf8');
if (componentMasterSource.includes("assert { type: 'json' }") || componentMasterSource.includes('assert { type: "json" }')) {
  fail('Post-patch validation failed: JSON import assertion remains in componentWeightMasterDb.js');
}

log('Patch Pack 4 V19-V19E applied.');
