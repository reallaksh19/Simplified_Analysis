# Patch Pack 3 — V18L Validation Checklist

## Static check

```bash
npm run check:v18l
```

## Behavior/static E2E hygiene check

```bash
npm run check:v18l:behavior
```

## Browser tests

```bash
npm run check:e2e:v18l
```

## Full certification

```bash
npm run certify:v18l
```

## Required browser-visible workflow

The browser must expose:

```text
2D Sketcher
  - sketcher-display-settings-panel
  - sketcher-toggle-node-coordinates
  - sketcher-toggle-segment-lengths
  - sketcher-element-listing-panel
  - sketcher-push-to-3d-simplified

3D Simplified Calculation
  - 3d-simplified-imported-model-summary
  - 3d-calculation-assignment-panel
  - 3d-support-load-results-panel
  - 3d-force-action-results-panel
  - 3d-simplified-suite-panel
  - 3d-simplified-report-panel
```

## Pass criteria

- V18L static check passes.
- V18L behavior check passes.
- Playwright browser workflow tests pass.
- `certify:v18l` produces `reports/v18l-certification-summary.json`.
