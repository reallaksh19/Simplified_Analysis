import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const packRoot = path.dirname(fileURLToPath(import.meta.url));
const repoRoot = process.cwd();
const payloadRoot = path.join(packRoot, 'payload');

function log(message) {
  console.log(`[V18L] ${message}`);
}

function fail(message) {
  console.error(`[V18L] ERROR: ${message}`);
  process.exit(1);
}

function write(rel, text) {
  const full = path.join(repoRoot, rel);
  fs.mkdirSync(path.dirname(full), { recursive: true });
  fs.writeFileSync(full, text, 'utf8');
}

function copyPayload(rel) {
  const source = path.join(payloadRoot, rel);
  if (!fs.existsSync(source)) fail(`Payload file missing: ${rel}`);
  write(rel, fs.readFileSync(source, 'utf8'));
  log(`wrote ${rel}`);
}

function patchFile(rel, patcher) {
  const full = path.join(repoRoot, rel);
  if (!fs.existsSync(full)) fail(`Target file missing: ${rel}`);
  const before = fs.readFileSync(full, 'utf8');
  const after = patcher(before);
  if (after !== before) {
    fs.writeFileSync(full, after, 'utf8');
    log(`patched ${rel}`);
  } else {
    log(`no changes needed in ${rel}`);
  }
}

for (const file of [
  'e2e/helpers/v18lWorkflowHelpers.js',
  'e2e/v18l-sketcher-display.spec.js',
  'e2e/v18l-sketcher-element-panel.spec.js',
  'e2e/v18l-push-to-3d-simplified.spec.js',
  'e2e/v18l-3d-calculation-workflow.spec.js',
  'scripts/v18l-browser-workflow-check.mjs',
  'scripts/v18l-browser-workflow-behavior-test.mjs',
  'scripts/v18l-release-certification.mjs',
]) {
  copyPayload(file);
}

patchFile('package.json', (input) => {
  const pkg = JSON.parse(input);
  pkg.scripts = pkg.scripts || {};

  const scripts = {
    'check:v18l': 'node scripts/v18l-browser-workflow-check.mjs',
    'check:v18l:behavior': 'node scripts/v18l-browser-workflow-behavior-test.mjs',
    'check:e2e:v18l': 'playwright test e2e/v18l-sketcher-display.spec.js e2e/v18l-sketcher-element-panel.spec.js e2e/v18l-push-to-3d-simplified.spec.js e2e/v18l-3d-calculation-workflow.spec.js',
    'certify:v18l': 'node scripts/v18l-release-certification.mjs',
    'ci:v18l': 'npm run ci:v18k && npm run check:v18l && npm run check:v18l:behavior && npm run check:e2e:v18l && npm run check:benchmarks && npm run build',
  };

  for (const [name, command] of Object.entries(scripts)) {
    pkg.scripts[name] = pkg.scripts[name] || command;
  }

  return `${JSON.stringify(pkg, null, 2)}\n`;
});

log('Patch Pack 3 V18L applied.');
log('Next commands: npm run check:v18l && npm run check:v18l:behavior && npm run check:e2e:v18l && npm run certify:v18l');
