# Simplified Analysis — Patch Pack 3 (V18L)

This is a **ready-to-apply browser workflow certification pack** for:

- **V18L** — Browser workflow certification for the Sketcher → 3D Simplified Calculation workflow

## Dependency

Apply and validate these first:

```text
Patch Pack 0 — V18A to V18C
Patch Pack 1 — V18D to V18F
Patch Pack 2 — V18G to V18K AUDIT_FIXED
```

## How to apply

Extract this zip into the root of the `Simplified_Analysis` repository. Then run from the repository root:

```bash
node Simplified_Analysis_PATCH_PACK_3_V18L_READY/apply-v18l-patch.mjs
```

Or copy the inner contents directly into the repo root and run:

```bash
node apply-v18l-patch.mjs
```

## Validation

```bash
npm run check:v18l
npm run check:v18l:behavior
npm run check:e2e:v18l
npm run certify:v18l
```

## What this pack adds

```text
e2e/helpers/v18lWorkflowHelpers.js
e2e/v18l-sketcher-display.spec.js
e2e/v18l-sketcher-element-panel.spec.js
e2e/v18l-push-to-3d-simplified.spec.js
e2e/v18l-3d-calculation-workflow.spec.js

scripts/v18l-browser-workflow-check.mjs
scripts/v18l-browser-workflow-behavior-test.mjs
scripts/v18l-release-certification.mjs
```

## Package scripts added

```json
"check:v18l": "node scripts/v18l-browser-workflow-check.mjs",
"check:v18l:behavior": "node scripts/v18l-browser-workflow-behavior-test.mjs",
"check:e2e:v18l": "playwright test e2e/v18l-sketcher-display.spec.js e2e/v18l-sketcher-element-panel.spec.js e2e/v18l-push-to-3d-simplified.spec.js e2e/v18l-3d-calculation-workflow.spec.js",
"certify:v18l": "node scripts/v18l-release-certification.mjs",
"ci:v18l": "npm run ci:v18k && npm run check:v18l && npm run check:v18l:behavior && npm run check:e2e:v18l && npm run check:benchmarks && npm run build"
```

## Important

This pack is certification-only. It does not add solver features. It ensures the V18A–V18K workflow is visible and testable in browser.


## Audit-fixed behavior

This audit-fixed pack avoids clicking the Sketcher push button on an empty sketch as a real action.
The test now verifies that the push button is present and trial-clickable, then navigates to the
3D tab to certify that all 3D Simplified Calculation panels are browser-visible.

The static check also verifies the existing Playwright configuration:
- `baseURL`
- `webServer`
- `npm run dev`
- `http://localhost:5173`
