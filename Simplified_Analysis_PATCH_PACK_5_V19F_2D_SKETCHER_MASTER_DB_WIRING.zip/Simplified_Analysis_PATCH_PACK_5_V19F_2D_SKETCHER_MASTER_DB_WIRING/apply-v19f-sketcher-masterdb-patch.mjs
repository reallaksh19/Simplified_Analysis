import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const packRoot = path.dirname(fileURLToPath(import.meta.url));
const repoRoot = process.cwd();
const payloadRoot = path.join(packRoot, 'payload');

function log(message) { console.log(`[V19F] ${message}`); }
function fail(message) { console.error(`[V19F] ERROR: ${message}`); process.exit(1); }

function write(rel, text) {
  const full = path.join(repoRoot, rel);
  fs.mkdirSync(path.dirname(full), { recursive: true });
  fs.writeFileSync(full, text, 'utf8');
}

function copyPayload(rel) {
  const source = path.join(payloadRoot, rel);
  if (!fs.existsSync(source)) fail(`Payload missing: ${rel}`);
  write(rel, fs.readFileSync(source, 'utf8'));
  log(`wrote ${rel}`);
}

function patchFile(rel, patcher) {
  const full = path.join(repoRoot, rel);
  if (!fs.existsSync(full)) fail(`Target missing: ${rel}`);
  const before = fs.readFileSync(full, 'utf8');
  const after = patcher(before);
  if (after !== before) {
    fs.writeFileSync(full, after, 'utf8');
    log(`patched ${rel}`);
  } else log(`no changes needed in ${rel}`);
}

function insertAfter(text, needle, insertion, label) {
  if (text.includes(insertion.trim())) return text;
  if (!text.includes(needle)) fail(`Patch point missing: ${label}`);
  return text.replace(needle, `${needle}${insertion}`);
}

function assertPatchedFileContains(rel, tokens) {
  const full = path.join(repoRoot, rel);
  if (!fs.existsSync(full)) fail(`Post-patch file missing: ${rel}`);
  const source = fs.readFileSync(full, 'utf8');
  for (const token of tokens) if (!source.includes(token)) fail(`Post-patch validation failed: ${rel} missing ${token}`);
}

for (const file of [
  'src/sketcher/componentProperties/segmentMasterDbInputs.js',
  'src/sketcher/SketcherMasterDbInsertPanel.jsx',
  'scripts/v19f-sketcher-masterdb-wiring-check.mjs',
  'scripts/v19f-sketcher-masterdb-wiring-behavior-test.mjs',
]) copyPayload(file);

patchFile('src/sketcher/SegmentEditorPanel.jsx', (input) => {
  let text = input;
  if (!text.includes("import SketcherMasterDbInsertPanel from './SketcherMasterDbInsertPanel.jsx';")) {
    const anchors = ["import { useSketchStore } from './SketcherStore';\n", "import React from 'react';\n"];
    let inserted = false;
    for (const anchor of anchors) {
      if (text.includes(anchor)) {
        text = text.replace(anchor, `${anchor}import SketcherMasterDbInsertPanel from './SketcherMasterDbInsertPanel.jsx';\n`);
        inserted = true;
        break;
      }
    }
    if (!inserted) fail('Could not insert SketcherMasterDbInsertPanel import.');
  }

  if (!text.includes('<SketcherMasterDbInsertPanel segmentId={selectedSegmentId} />')) {
    const anchors = ["                <div style={section}>Pipe</div>", "                <div style={section}>Line / Component Class</div>", "                <button"];
    let inserted = false;
    for (const anchor of anchors) {
      if (text.includes(anchor)) {
        text = text.replace(anchor, `                <SketcherMasterDbInsertPanel segmentId={selectedSegmentId} />\n\n${anchor}`);
        inserted = true;
        break;
      }
    }
    if (!inserted) fail('Could not insert SketcherMasterDbInsertPanel render call.');
  }

  return text;
});

patchFile('src/sketcher/ElementListingPanel.jsx', (input) => {
  let text = input;

  text = insertAfter(
    text,
    "import { useSketchStore } from './SketcherStore';\n",
    "import { resolveFlangeValveFlangeInsertData } from './componentProperties/componentMasterResolver.js';\nimport { resolveReducerInsertData } from './componentProperties/b169FittingMasterResolver.js';\n",
    'ElementListingPanel master DB resolver imports',
  );

  const helper = `
function QuickInsertButtons() {
  const selectedSegmentId = useSketchStore((s) => s.selectedSegmentId);
  const segments = useSketchStore((s) => s.segments || []);
  const insertReducerOnSelectedSegment = useSketchStore((s) => s.insertReducerOnSelectedSegment);
  const insertFlangeValveFlangeOnSelectedSegment = useSketchStore((s) => s.insertFlangeValveFlangeOnSelectedSegment);
  const selectedSegment = segments.find((segment) => segment.id === selectedSegmentId);
  const selectedDn = selectedSegment?.pipe?.dn ?? selectedSegment?.properties?.bore ?? 200;
  const ratingClass = selectedSegment?.lineClass?.ratingClass ?? selectedSegment?.properties?.ratingClass ?? 300;
  const faceType = selectedSegment?.lineClass?.faceType ?? selectedSegment?.properties?.faceType ?? 'RF';
  const flangeType = selectedSegment?.lineClass?.flangeType ?? selectedSegment?.properties?.flangeType ?? 'WN';
  const valveType = selectedSegment?.lineClass?.valveType ?? selectedSegment?.properties?.valveType ?? 'Flanged Swing check Valve';
  const schedule = selectedSegment?.pipe?.schedule ?? selectedSegment?.properties?.schedule ?? 'STD';

  return (
    <div style={{ display: 'flex', gap: 6 }}>
      <button type="button" data-testid="element-panel-insert-reducer" disabled={!selectedSegmentId} style={{ ...actionButtonStyle, opacity: selectedSegmentId ? 1 : 0.45 }} onClick={() => { const targetDn = selectedDn > 50 ? selectedDn - 50 : selectedDn; insertReducerOnSelectedSegment?.(resolveReducerInsertData({ fromDn: selectedDn, toDn: targetDn, reducerType: 'CONCENTRIC', scheduleFrom: schedule, scheduleTo: schedule })); }}>Insert Reducer</button>
      <button type="button" data-testid="element-panel-insert-fvf" disabled={!selectedSegmentId} style={{ ...actionButtonStyle, opacity: selectedSegmentId ? 1 : 0.45 }} onClick={() => { insertFlangeValveFlangeOnSelectedSegment?.(resolveFlangeValveFlangeInsertData({ dn: selectedDn, ratingClass, valveType, flangeType, faceType })); }}>Insert F-V-F</button>
    </div>
  );
}

`;

  if (!text.includes('function QuickInsertButtons()')) text = text.replace('export default function ElementListingPanel()', `${helper}export default function ElementListingPanel()`);

  if (!text.includes('<QuickInsertButtons />')) {
    const anchors = ["<strong style={{ color: '#e0f2fe' }}>Element Listing</strong>", "<strong>Element Listing</strong>"];
    let inserted = false;
    for (const anchor of anchors) {
      if (text.includes(anchor)) {
        text = text.replace(anchor, `${anchor}\n          <QuickInsertButtons />`);
        inserted = true;
        break;
      }
    }
    if (!inserted) fail('Could not insert QuickInsertButtons into ElementListingPanel header.');
  }

  return text;
});

patchFile('package.json', (input) => {
  const pkg = JSON.parse(input);
  pkg.scripts = pkg.scripts || {};
  const scripts = {
    'check:v19f': 'node scripts/v19f-sketcher-masterdb-wiring-check.mjs',
    'check:v19f:behavior': 'node scripts/v19f-sketcher-masterdb-wiring-behavior-test.mjs',
    'ci:v19f': 'npm run ci:v19e && npm run check:v19f && npm run check:v19f:behavior && npm run check:benchmarks && npm run build',
  };
  for (const [name, command] of Object.entries(scripts)) pkg.scripts[name] = pkg.scripts[name] || command;
  return `${JSON.stringify(pkg, null, 2)}\n`;
});

assertPatchedFileContains('src/sketcher/SegmentEditorPanel.jsx', ['SketcherMasterDbInsertPanel', '<SketcherMasterDbInsertPanel segmentId={selectedSegmentId} />']);
assertPatchedFileContains('src/sketcher/ElementListingPanel.jsx', ['element-panel-insert-reducer', 'element-panel-insert-fvf', 'resolveReducerInsertData', 'resolveFlangeValveFlangeInsertData']);

log('Patch Pack 5 V19F 2D Sketcher Master DB wiring applied.');
