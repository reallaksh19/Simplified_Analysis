# Simplified Analysis — Patch Pack 2 (V18G to V18K)

This is a **ready-to-apply patch pack** for:

- **V18G** — Push 2D Sketcher model to 3D Simplified Calculation
- **V18H** — 3D assignment panel
- **V18I** — Support deadweight load solver
- **V18J** — Guided-cantilever suite wrapper
- **V18J2** — Force action solver
- **V18K** — 3D simplified calculation report

## Dependency

Apply and validate these first:

```text
Patch Pack 0 — V18A to V18C
Patch Pack 1 — V18D to V18F
```

## How to apply

Extract this zip into the root of the `Simplified_Analysis` repository. Then run from the repository root:

```bash
node Simplified_Analysis_PATCH_PACK_2_V18G_to_V18K_READY/apply-v18gk-patch.mjs
```

Or copy the inner contents directly into the repo root and run:

```bash
node apply-v18gk-patch.mjs
```

## Validation

```bash
npm run check:v18g
npm run check:v18g:behavior
npm run check:v18h
npm run check:v18h:behavior
npm run check:v18i
npm run check:v18i:behavior
npm run check:v18j
npm run check:v18j:behavior
npm run check:v18j2
npm run check:v18j2:behavior
npm run check:v18k
npm run check:v18k:behavior
npm run build
```

## Safety notes

This pack does not remove the existing GC3D workflow. It adds the 3D Simplified Calculation workflow beside the existing GC3D data/results and keeps `runAnalysis()` intact.


## Audit-fixed behavior

This audit-fixed pack includes corrections for:
- robust SketcherStore state insertion
- UI test id for Sketcher → 3D push
- empty-model report blocking
- inline component load distribution to nearest supports
- GC3D status propagation in the 3D suite
