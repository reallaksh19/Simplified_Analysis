# Patch Pack 2 Audit Note

This pack is built against the current repository shape where the 3D module uses:

```text
src/3d-analysis/AnalysisStore.js
src/3d-analysis/AnalysisTab.jsx
```

rather than `src/3d-analysis/store/useAnalysisStore.js`.

It intentionally preserves the existing GC3D `runAnalysis()` workflow and adds new 3D Simplified Calculation actions beside it.

Final integrated certification still requires applying this pack after Packs 0 and 1 and running all V18G–V18K checks plus `npm run build`.


## Static Review Fixes Applied

1. `apply-v18gk-patch.mjs` no longer depends only on the missing `topologyValidationSummary` state anchor.
   It now tries several compatible SketcherStore anchors.
2. The Sketcher push button now gets `data-testid="sketcher-push-to-3d-simplified"`.
3. V18G static check now verifies the visible push button test id.
4. Support-load solver now fails an empty model and distributes inline component weight to nearest support nodes.
5. Force-action solver now returns `PASSED` when there are no diagnostics instead of unconditional `PASSED_WITH_WARNINGS`.
6. Guided-cantilever suite now propagates non-passing GC3D status instead of always returning `PASSED`.
7. Report builder now blocks report issue when the 3D model is missing or empty.
