import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const packRoot = path.dirname(fileURLToPath(import.meta.url));
const repoRoot = process.cwd();
const payloadRoot = path.join(packRoot, 'payload');

function log(message) { console.log(`[V18G-K] ${message}`); }
function fail(message) { console.error(`[V18G-K] ERROR: ${message}`); process.exit(1); }

function write(rel, text) {
  const full = path.join(repoRoot, rel);
  fs.mkdirSync(path.dirname(full), { recursive: true });
  fs.writeFileSync(full, text, 'utf8');
}

function copyPayload(rel) {
  const source = path.join(payloadRoot, rel);
  if (!fs.existsSync(source)) fail(`Payload file missing: ${rel}`);
  write(rel, fs.readFileSync(source, 'utf8'));
  log(`wrote ${rel}`);
}

function patchFile(rel, patcher) {
  const full = path.join(repoRoot, rel);
  if (!fs.existsSync(full)) fail(`Target file missing: ${rel}`);
  const before = fs.readFileSync(full, 'utf8');
  const after = patcher(before);
  if (after !== before) {
    fs.writeFileSync(full, after, 'utf8');
    log(`patched ${rel}`);
  } else {
    log(`no changes needed in ${rel}`);
  }
}

function insertAfter(text, needle, insertion, label) {
  if (text.includes(insertion.trim())) return text;
  if (!text.includes(needle)) fail(`Could not find insertion point: ${label}`);
  return text.replace(needle, `${needle}${insertion}`);
}

for (const file of [
  'src/sketcher/adapters/sketcherTo3DCalculationModel.js',
  'src/core/solvers/supportLoads/solveSupportLoads3D.js',
  'src/core/solvers/forceActions/solve3DForceActions.js',
  'src/3d-analysis/solverSuite/run3DSimplifiedCalculationSuite.js',
  'src/3d-analysis/reporting/build3DSimplifiedCalculationReport.js',
  'src/3d-analysis/CalculationAssignmentPanel.jsx',
  'src/3d-analysis/SupportLoadResultsPanel.jsx',
  'src/3d-analysis/ForceActionResultsPanel.jsx',
  'src/3d-analysis/SimplifiedCalculationSuitePanel.jsx',
  'src/3d-analysis/Report3DSimplifiedPanel.jsx',
  'scripts/v18g-sketcher-to-3d-check.mjs',
  'scripts/v18g-sketcher-to-3d-behavior-test.mjs',
  'scripts/v18h-3d-assignment-check.mjs',
  'scripts/v18h-3d-assignment-behavior-test.mjs',
  'scripts/v18i-support-loads-check.mjs',
  'scripts/v18i-support-loads-behavior-test.mjs',
  'scripts/v18j-suite-check.mjs',
  'scripts/v18j-suite-behavior-test.mjs',
  'scripts/v18j2-force-actions-check.mjs',
  'scripts/v18j2-force-actions-behavior-test.mjs',
  'scripts/v18k-report-check.mjs',
  'scripts/v18k-report-behavior-test.mjs',
]) {
  copyPayload(file);
}

patchFile('src/sketcher/SketcherStore.js', (input) => {
  let text = input;

  text = insertAfter(
    text,
    "import { serializePCFX, parsePCFXText, downloadTextFile, makePCFXFilename } from '../core/pcfx/pcfxFileUtils.js';\n",
    "import { build3DCalculationModelFromSketcher } from './adapters/sketcherTo3DCalculationModel.js';\n",
    'SketcherStore V18G import',
  );

  if (!text.includes('last3DCalculationModel: null')) {
    const stateInsertion = "  last3DCalculationModel: null,\n  last3DPushDiagnostics: [],\n";
    const stateAnchors = [
      "  lastImportLossContract: [],\n",
      "  lastImportDiagnostics: [],\n",
      "  topologyDiagnostics: [],\n",
      "  importWarnings: [],\n",
      "  segments: [],\n",
    ];

    let inserted = false;
    for (const anchor of stateAnchors) {
      if (text.includes(anchor)) {
        text = text.replace(anchor, `${anchor}${stateInsertion}`);
        inserted = true;
        break;
      }
    }

    if (!inserted) fail('Could not find insertion point: SketcherStore V18G state');
  }

  text = insertAfter(
    text,
    `  exportToComponents: () => {
      const { nodes, segments } = get();
      return buildComponentsFromGraph(nodes, segments);
  },

`,
    `  build3DCalculationModel: () => {
      const { nodes, segments, components, designTemperature, workingPlane } = get();
      const model = build3DCalculationModelFromSketcher({
          nodes,
          segments,
          components: components || {},
          settings: { designTemperature, workingPlane },
      });
      set({
          last3DCalculationModel: model,
          last3DPushDiagnostics: model.diagnostics || [],
      });
      return model;
  },

  pushTo3DSimplifiedCalculation: () => {
      const model = get().build3DCalculationModel();
      set({
          last3DCalculationModel: model,
          last3DPushDiagnostics: model.diagnostics || [],
      });
      return model;
  },

`,
    'SketcherStore V18G actions',
  );

  return text;
});

patchFile('src/sketcher/SketcherTab.jsx', (input) => {
  let text = input;

  if (text.includes("const { nodes, segments, designTemperature } = useSketchStore.getState();")) {
    text = text.replace(
      `        const { nodes, segments, designTemperature } = useSketchStore.getState();
        if (Object.keys(nodes).length === 0 || segments.length === 0) {
            alert('Sketch is empty — draw at least one pipe segment before pushing.');
            return;
        }
        useAnalysisStore.getState().importFromSketcher(nodes, segments, { designTemperature });
        setActiveTab('3d-analysis');`,
      `        const sketchState = useSketchStore.getState();
        const { nodes, segments, designTemperature } = sketchState;
        if (Object.keys(nodes).length === 0 || segments.length === 0) {
            alert('Sketch is empty — draw at least one pipe segment before pushing.');
            return;
        }
        const model = sketchState.pushTo3DSimplifiedCalculation
            ? sketchState.pushTo3DSimplifiedCalculation()
            : null;
        const analysisStore = useAnalysisStore.getState();
        if (model && analysisStore.importCalculationModel) {
            analysisStore.importCalculationModel(model);
        } else {
            analysisStore.importFromSketcher(nodes, segments, { designTemperature });
        }
        setActiveTab('3d-analysis');`
    );
  }

  text = text.replace('Push to 3D GC', 'Push to 3D Simplified');
  text = text.replace('title="Push sketch to 3D Guided Cantilever solver"', 'title="Push sketch to 3D Simplified Calculation"');
  text = text.replace(
    '<button title="Push sketch to 3D Simplified Calculation"',
    '<button data-testid="sketcher-push-to-3d-simplified" title="Push sketch to 3D Simplified Calculation"'
  );
  return text;
});

patchFile('src/3d-analysis/AnalysisStore.js', (input) => {
  let text = input;

  text = insertAfter(
    text,
    "import { solveGC3D } from '../solvers/3d/solveGC3D.js';\n",
    "import { validate3DCalculationModel } from '../sketcher/adapters/sketcherTo3DCalculationModel.js';\nimport { solveSupportLoads3D } from '../core/solvers/supportLoads/solveSupportLoads3D.js';\nimport { solve3DForceActions } from '../core/solvers/forceActions/solve3DForceActions.js';\nimport { runGuidedCantileverFromCalculationModel, run3DSimplifiedCalculationSuite as runSuite } from './solverSuite/run3DSimplifiedCalculationSuite.js';\nimport { build3DSimplifiedCalculationReport, export3DSimplifiedReportJson, export3DSimplifiedReportMarkdown, export3DSimplifiedReportHtml } from './reporting/build3DSimplifiedCalculationReport.js';\n",
    'AnalysisStore V18G-K imports',
  );

  text = insertAfter(
    text,
    "  debugLog: [],\n",
    "  calculationModel: null,\n  calculationModelDiagnostics: [],\n  calculationModelSource: null,\n  selectedCalculationElement: null,\n  calculationAssignmentDiagnostics: [],\n  supportLoadResult: null,\n  supportLoadDiagnostics: [],\n  forceActionResult: null,\n  forceActionDiagnostics: [],\n  guidedCantileverThermalResult: null,\n  simplified3DSuiteResult: null,\n  simplified3DSuiteDiagnostics: [],\n  simplified3DReport: null,\n  simplified3DReportExports: null,\n",
    'AnalysisStore V18G-K state',
  );

  text = insertAfter(
    text,
    `  clearLog: () => set({ debugLog: [], logCounter: 0 }),

`,
    `  importCalculationModel: (model) => {
    const validation = validate3DCalculationModel(model || {});
    set({
      calculationModel: model,
      calculationModelDiagnostics: validation.diagnostics || [],
      calculationModelSource: model?.source || 'unknown',
      selectedCalculationElement: null,
      calculationAssignmentDiagnostics: validation.diagnostics || [],
    });
    return validation;
  },

  setSelectedCalculationElement: (selection) => set({ selectedCalculationElement: selection }),
  clearSelectedCalculationElement: () => set({ selectedCalculationElement: null }),

  updateCalculationSegment: (segmentId, updates) => {
    set((s) => ({
      calculationModel: {
        ...(s.calculationModel || {}),
        segments: (s.calculationModel?.segments || []).map((seg) =>
          seg.id === segmentId ? { ...seg, ...updates } : seg
        ),
      },
    }));
  },

  updateCalculationSupport: (supportId, updates) => {
    set((s) => ({
      calculationModel: {
        ...(s.calculationModel || {}),
        supports: (s.calculationModel?.supports || []).map((support) =>
          support.id === supportId || support.nodeId === supportId ? { ...support, ...updates } : support
        ),
      },
    }));
  },

  validateCalculationAssignments: () => {
    const model = get().calculationModel;
    const validation = validate3DCalculationModel(model || {});
    set({ calculationAssignmentDiagnostics: validation.diagnostics || [], calculationModelDiagnostics: validation.diagnostics || [] });
    return validation;
  },

  runSupportLoadCalculation: () => {
    const model = get().calculationModel;
    const result = solveSupportLoads3D(model || {});
    set({ supportLoadResult: result, supportLoadDiagnostics: result.diagnostics || [] });
    return result;
  },

  runForceActionCalculation: () => {
    const model = get().calculationModel;
    const supportLoadResult = get().supportLoadResult || get().runSupportLoadCalculation();
    const result = solve3DForceActions(model || {}, { supportLoadResult });
    set({ forceActionResult: result, forceActionDiagnostics: result.diagnostics || [] });
    return result;
  },

  runGuidedCantileverThermalCalculation: () => {
    const model = get().calculationModel;
    const result = runGuidedCantileverFromCalculationModel(model || {}, get().params);
    set({ guidedCantileverThermalResult: result });
    return result;
  },

  run3DSimplifiedCalculationSuite: () => {
    const model = get().calculationModel;
    const result = runSuite(model || {}, get().params);
    set({
      simplified3DSuiteResult: result,
      supportLoadResult: result.results?.supportLoads || get().supportLoadResult,
      forceActionResult: result.results?.forceActions || get().forceActionResult,
      guidedCantileverThermalResult: result.results?.guidedCantileverThermal || get().guidedCantileverThermalResult,
      simplified3DSuiteDiagnostics: result.diagnostics || [],
    });
    return result;
  },

  buildSimplified3DReport: (options = {}) => {
    const report = build3DSimplifiedCalculationReport({
      model: get().calculationModel,
      supportLoadResult: get().supportLoadResult,
      forceActionResult: get().forceActionResult,
      guidedCantileverThermalResult: get().guidedCantileverThermalResult,
      suiteResult: get().simplified3DSuiteResult,
      issueType: options.issueType || 'SCREENING_ISSUE',
    });
    set({
      simplified3DReport: report,
      simplified3DReportExports: {
        json: export3DSimplifiedReportJson(report),
        markdown: export3DSimplifiedReportMarkdown(report),
        html: export3DSimplifiedReportHtml(report),
      },
    });
    return report;
  },

`,
    'AnalysisStore V18G-K actions',
  );

  return text;
});

patchFile('src/3d-analysis/AnalysisTab.jsx', (input) => {
  let text = input;

  text = insertAfter(
    text,
    "import { ConfigPanel } from './ConfigPanel';\n",
    "import CalculationAssignmentPanel from './CalculationAssignmentPanel';\nimport SupportLoadResultsPanel from './SupportLoadResultsPanel';\nimport ForceActionResultsPanel from './ForceActionResultsPanel';\nimport SimplifiedCalculationSuitePanel from './SimplifiedCalculationSuitePanel';\nimport Report3DSimplifiedPanel from './Report3DSimplifiedPanel';\n",
    'AnalysisTab V18G-K imports',
  );

  text = text.replace(
    "  const { includeSIF, setIncludeSIF, colorMode, setColorMode, dataGridCollapsed, toggleDataGrid } = useAnalysisStore();",
    "  const { includeSIF, setIncludeSIF, colorMode, setColorMode, dataGridCollapsed, toggleDataGrid, calculationModel } = useAnalysisStore();"
  );

  if (!text.includes('3d-simplified-imported-model-summary')) {
    text = text.replace(
      "            <ComponentPanel />",
      "            <ComponentPanel />\n\n            <div data-testid=\"3d-simplified-imported-model-summary\" style={{ position: 'absolute', left: '16px', bottom: '16px', background: 'rgba(15,23,42,0.9)', border: '1px solid #334155', borderRadius: '8px', padding: '8px 10px', color: '#cbd5e1', fontSize: '12px', zIndex: 10 }}>\n              3D Simplified Model: {calculationModel ? `${Object.keys(calculationModel.nodes || {}).length} nodes / ${(calculationModel.segments || []).length} segments` : 'not imported'}\n            </div>"
    );
  }

  if (!text.includes('<CalculationAssignmentPanel />')) {
    text = text.replace(
      "                          <DebugTable />",
      "                          <CalculationAssignmentPanel />\n                          <SupportLoadResultsPanel />\n                          <ForceActionResultsPanel />\n                          <SimplifiedCalculationSuitePanel />\n                          <Report3DSimplifiedPanel />\n                          <DebugTable />"
    );
  }

  return text;
});

patchFile('package.json', (input) => {
  const pkg = JSON.parse(input);
  pkg.scripts = pkg.scripts || {};
  const scripts = {
    'check:v18g': 'node scripts/v18g-sketcher-to-3d-check.mjs',
    'check:v18g:behavior': 'node scripts/v18g-sketcher-to-3d-behavior-test.mjs',
    'check:v18h': 'node scripts/v18h-3d-assignment-check.mjs',
    'check:v18h:behavior': 'node scripts/v18h-3d-assignment-behavior-test.mjs',
    'check:v18i': 'node scripts/v18i-support-loads-check.mjs',
    'check:v18i:behavior': 'node scripts/v18i-support-loads-behavior-test.mjs',
    'check:v18j': 'node scripts/v18j-suite-check.mjs',
    'check:v18j:behavior': 'node scripts/v18j-suite-behavior-test.mjs',
    'check:v18j2': 'node scripts/v18j2-force-actions-check.mjs',
    'check:v18j2:behavior': 'node scripts/v18j2-force-actions-behavior-test.mjs',
    'check:v18k': 'node scripts/v18k-report-check.mjs',
    'check:v18k:behavior': 'node scripts/v18k-report-behavior-test.mjs',
    'ci:v18k': 'npm run ci:v18f && npm run check:v18g && npm run check:v18g:behavior && npm run check:v18h && npm run check:v18h:behavior && npm run check:v18i && npm run check:v18i:behavior && npm run check:v18j && npm run check:v18j:behavior && npm run check:v18j2 && npm run check:v18j2:behavior && npm run check:v18k && npm run check:v18k:behavior && npm run check:benchmarks && npm run build',
  };
  for (const [name, command] of Object.entries(scripts)) pkg.scripts[name] = pkg.scripts[name] || command;
  return `${JSON.stringify(pkg, null, 2)}\n`;
});

log('Patch Pack 2 V18G-K applied.');
log('Next: run npm run check:v18g ... npm run check:v18k:behavior && npm run build');
