export const REPORT_3D_SIMPLIFIED_SCHEMA_VERSION = 'report-3d-simplified-v18k';

function fmt(value, digits = 2) {
  const n = Number(value);
  return Number.isFinite(n) ? n.toFixed(digits) : '—';
}

function collectDiagnostics(...items) {
  const out = [];
  for (const item of items) {
    if (!item) continue;
    if (Array.isArray(item)) out.push(...item);
    else if (Array.isArray(item.diagnostics)) out.push(...item.diagnostics);
  }
  return out;
}

function buildIssueBlockers({ model, issueType, diagnostics, supportLoadResult, forceActionResult, guidedCantileverThermalResult }) {
  const blockers = [];

  if (!model || !Array.isArray(model.segments) || model.segments.length === 0) {
    blockers.push({
      code: 'MODEL_MISSING_OR_EMPTY',
      message: 'A 3D calculation model with at least one segment is required before issuing a report.',
    });
  }

  if (issueType === 'FINAL_ISSUE') {
    blockers.push({
      code: 'FINAL_ISSUE_BLOCKED_SCREENING_METHOD',
      message: '3D Simplified Calculation is screening-level and cannot be issued as final stress analysis.',
    });
  }

  for (const item of diagnostics || []) {
    if (item.severity === 'error') {
      blockers.push({ code: item.code || 'DIAGNOSTIC_ERROR', message: item.message || 'Diagnostic error.', data: item.data || {} });
    }
  }

  for (const [label, result] of [
    ['support load', supportLoadResult],
    ['force action', forceActionResult],
    ['guided-cantilever thermal', guidedCantileverThermalResult],
  ]) {
    if (result?.status === 'NOT_QUALIFIED') {
      blockers.push({ code: 'CALCULATION_NOT_QUALIFIED', message: `${label} calculation is not qualified.` });
    }
  }

  return blockers;
}

function summarizePipeSegments(model = {}) {
  return (model.segments || []).filter((segment) => String(segment.type || segment.properties?.type || 'PIPE').toUpperCase() === 'PIPE').map((segment) => ({
    id: segment.id,
    from: segment.startNode,
    to: segment.endNode,
    dn: segment.pipe?.dn ?? segment.properties?.bore ?? null,
    ratingClass: segment.lineClass?.ratingClass ?? segment.properties?.ratingClass ?? null,
    faceType: segment.lineClass?.faceType ?? segment.properties?.faceType ?? null,
    flangeType: segment.lineClass?.flangeType ?? segment.properties?.flangeType ?? null,
    schedule: segment.pipe?.schedule ?? segment.properties?.schedule ?? null,
    wall_mm: segment.pipe?.wall_mm ?? segment.properties?.wt ?? null,
    designTemperature_C: segment.operating?.designTemperature_C ?? segment.properties?.designTemperature_C ?? null,
    designPressure_barg: segment.operating?.designPressure_barg ?? segment.properties?.designPressure_barg ?? null,
    fluidDensity_kg_m3: segment.contents?.fluidDensity_kg_m3 ?? segment.properties?.fluidDensity_kg_m3 ?? null,
    insulationThickness_mm: segment.insulation?.thickness_mm ?? segment.properties?.insulation ?? null,
  }));
}

function summarizeComponents(model = {}) {
  return Object.values(model.components || {}).map((component) => ({
    id: component.id,
    type: component.type,
    length_mm: component.length_mm ?? component.totalLength_mm ?? null,
    weight_kg: component.weight_kg ?? component.totalWeight_kg ?? null,
    sourceStatus: component.sourceStatus ?? component.dataStatus ?? 'UNKNOWN',
  }));
}

export function build3DSimplifiedCalculationReport({
  model = null,
  supportLoadResult = null,
  forceActionResult = null,
  guidedCantileverThermalResult = null,
  suiteResult = null,
  issueType = 'SCREENING_ISSUE',
} = {}) {
  const diagnostics = collectDiagnostics(
    model?.diagnostics || [],
    supportLoadResult,
    forceActionResult,
    guidedCantileverThermalResult,
    suiteResult,
  );

  const blockers = buildIssueBlockers({
    model,
    issueType,
    diagnostics,
    supportLoadResult,
    forceActionResult,
    guidedCantileverThermalResult,
  });

  const report = {
    schemaVersion: REPORT_3D_SIMPLIFIED_SCHEMA_VERSION,
    issueType,
    status: blockers.length ? 'BLOCKED' : 'PASSED',
    generatedAt: new Date(0).toISOString(),
    modelSummary: {
      nodeCount: Object.keys(model?.nodes || {}).length,
      segmentCount: model?.segments?.length || 0,
      componentCount: Object.keys(model?.components || {}).length,
      supportCount: model?.supports?.length || 0,
    },
    pipeSegments: summarizePipeSegments(model || {}),
    components: summarizeComponents(model || {}),
    calculations: {
      supportLoadResult,
      forceActionResult,
      guidedCantileverThermalResult,
      suiteResult,
    },
    diagnostics,
    blockers,
    assumptions: [
      '3D Simplified Calculation is screening-level and does not replace detailed code-compliance stress analysis.',
      'Deadweight support distribution uses simplified end-support allocation.',
      'Guided-cantilever thermal result is coupled at report level, not mixed into deadweight equations.',
    ],
  };

  return {
    ...report,
    markdown: export3DSimplifiedReportMarkdown(report),
    html: export3DSimplifiedReportHtml(report),
  };
}

export function export3DSimplifiedReportJson(report) {
  return JSON.stringify(report, null, 2);
}

export function export3DSimplifiedReportMarkdown(report) {
  const lines = [];
  lines.push('# 3D Simplified Calculation Report');
  lines.push('');
  lines.push(`Issue type: ${report.issueType}`);
  lines.push(`Status: ${report.status}`);
  lines.push('');
  lines.push('## 1. Model Summary');
  lines.push('');
  lines.push(`Nodes: ${report.modelSummary.nodeCount}`);
  lines.push(`Segments: ${report.modelSummary.segmentCount}`);
  lines.push(`Components: ${report.modelSummary.componentCount}`);
  lines.push(`Supports: ${report.modelSummary.supportCount}`);
  lines.push('');
  lines.push('## 2. Pipe Input Summary');
  lines.push('');
  lines.push('| ID | From | To | DN | Class | Face | Flange | Sch | WT mm | Temp °C | Press barg | Fluid kg/m³ | Insul mm |');
  lines.push('|---|---|---|---:|---|---|---|---|---:|---:|---:|---:|---:|');
  for (const seg of report.pipeSegments || []) {
    lines.push(`| ${seg.id} | ${seg.from} | ${seg.to} | ${seg.dn ?? '—'} | CL${seg.ratingClass ?? '—'} | ${seg.faceType ?? '—'} | ${seg.flangeType ?? '—'} | ${seg.schedule ?? '—'} | ${fmt(seg.wall_mm)} | ${fmt(seg.designTemperature_C)} | ${fmt(seg.designPressure_barg)} | ${fmt(seg.fluidDensity_kg_m3)} | ${fmt(seg.insulationThickness_mm)} |`);
  }
  lines.push('');
  lines.push('## 3. Support Loads');
  lines.push('');
  lines.push(`Status: ${report.calculations.supportLoadResult?.status || 'NOT_RUN'}`);
  lines.push(`Total weight N: ${fmt(report.calculations.supportLoadResult?.summary?.totalWeight_N)}`);
  lines.push('');
  lines.push('## 4. Force Actions');
  lines.push('');
  lines.push(`Status: ${report.calculations.forceActionResult?.status || 'NOT_RUN'}`);
  lines.push('');
  lines.push('## 5. Guided-Cantilever Thermal');
  lines.push('');
  lines.push(`Status: ${report.calculations.guidedCantileverThermalResult?.status || 'NOT_RUN'}`);
  lines.push('');
  lines.push('## 6. Issue Blockers');
  lines.push('');
  if (report.blockers?.length) {
    for (const blocker of report.blockers) lines.push(`- **${blocker.code}:** ${blocker.message}`);
  } else {
    lines.push('No issue blockers.');
  }
  lines.push('');
  lines.push('## 7. Assumptions');
  lines.push('');
  for (const assumption of report.assumptions || []) lines.push(`- ${assumption}`);
  lines.push('');
  return lines.join('\n');
}

export function export3DSimplifiedReportHtml(report) {
  const md = report.markdown || export3DSimplifiedReportMarkdown(report);
  return `<html><body><pre>${md.replace(/[&<>]/g, (ch) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;' }[ch]))}</pre></body></html>`;
}
