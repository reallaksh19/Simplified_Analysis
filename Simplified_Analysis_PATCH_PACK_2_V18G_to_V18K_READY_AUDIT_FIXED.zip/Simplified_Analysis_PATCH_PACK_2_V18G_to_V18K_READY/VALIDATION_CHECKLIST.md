# Patch Pack 2 Validation Checklist

## Static checks

```bash
npm run check:v18g
npm run check:v18h
npm run check:v18i
npm run check:v18j
npm run check:v18j2
npm run check:v18k
```

## Behavior checks

```bash
npm run check:v18g:behavior
npm run check:v18h:behavior
npm run check:v18i:behavior
npm run check:v18j:behavior
npm run check:v18j2:behavior
npm run check:v18k:behavior
```

## Build

```bash
npm run build
```

## Manual UI smoke test

1. Open 2D Sketcher.
2. Draw a pipe segment or import geometry.
3. Assign pipe properties, line class, temperature, pressure, fluid and insulation.
4. Click Push to 3D Simplified Calculation.
5. Confirm imported model summary appears.
6. In 3D tab, run:
   - Validate assignments
   - Support loads
   - Force actions
   - Guided-cantilever thermal
   - Full simplified suite
   - Build report
7. Confirm report preview appears and final issue is blocked for screening workflow.
